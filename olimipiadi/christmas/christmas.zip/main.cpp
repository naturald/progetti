#include <iostream>
#include <algorithm>
using namespace std;

int eff(int n,int b,int gifts[n],int ans=0,int prova=0,int volte=0)
{
  if(prova==b)
    return ans;
  if(volte==0)
    ans=2000000000;
  int tot=0,prova2=prova,comodo;
  for(int i=0;i<n;i++)
  {
    if((gifts[i]+0)==b)
    {
      cout<<gifts[i];
      return ans;
    }
    for(int j=0;j<n;j++)
    {
      if((prova+gifts[j])==b)
      {
        return prova+gifts[j];
      }
      if((prova+gifts[j])<ans&&(prova+gifts[j])>b)
      {
        ans=(prova+gifts[j]);
      }
      if(i==j)
        continue;
      prova2=prova+(gifts[i]+gifts[j]);
      if(prova2==b)
      {
        return prova2;
      }

      if(prova2<ans&&prova2>b)
      {
        ans=prova2;
        prova2=prova;
      }
      else
      {
        if(prova2<b)
        {
          volte++;
          comodo=eff(n,b,gifts,ans,prova2,volte);
          return comodo;
        }
        prova2=prova;
      }
    }
  }
  return ans;
}

int main() 
{
  int n,b,tot=0;
  cin>>n >>b;
  int gifts[n];
  for(int i=0;i<n;i++)
  {
    cin>>gifts[i];
    tot+=gifts[i];
  }
  if(tot<=b)
  {
    cout<<tot;
    return 0;
  }
  sort(gifts, gifts + n);
  if(b==0)
  {
    cout<<gifts[0];
    return 0;
  }
  reverse(gifts, gifts + n);
  cout<<"\n\n\n";
  
  cout<<eff(n,b,gifts);
}